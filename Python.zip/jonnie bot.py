import telebot
from telebot import types

Token = '1261946263:AAEQJ2ZJ_I36GAGPt6b7o7T60CaCb638sjM'

bot = telebot.TeleBot(Token)

@bot.message_handler(commands = ['start'])
def welcome(message):

  #keyboard
  markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
  btn1 = types.KeyboardButton("🎵When I see you again🎵")
  btn2 = types.KeyboardButton("🎵Warriors🎵")
  btn3 = types.KeyboardButton("🎵Heart Afire🎵")
  btn4 = types.KeyboardButton("🎵NCS Playlist🎵")
  btn5 = types.KeyboardButton("🎵Don't leave me now🎵")

  markup.add(btn1, btn2, btn3, btn4, btn5)

  bot.send_message(message.chat.id, "{0.first_name}, Виберіть пісню:".format(message.from_user,bot.get_me()),
  parse_mode='html', reply_markup=markup)

@bot.message_handler(content_types = ['text'])
def lalala(message):

  if message.chat.type == 'private':
    if message.text == '🎵When I see you again🎵':
      bot.send_message(message.chat.id, 'https://www.youtube.com/watch?v=RgKAFK5djSk')
    elif message.text == '🎵Warriors🎵':
      bot.send_message(message.chat.id, 'https://www.youtube.com/watch?v=fmI_Ndrxy14')
    elif message.text == '🎵Heart Afire🎵':
      bot.send_message(message.chat.id, 'https://www.youtube.com/watch?v=I6-StvDpck4')
    elif message.text == '🎵NCS Playlist🎵':
      bot.send_message(message.chat.id, 'https://www.youtube.com/watch?v=ABuNwLP-z9o')
    elif message.text == "🎵Don't leave me now🎵":
      bot.send_message(message.chat.id,'https://www.youtube.com/watch?v=FQFfI9cC35w')
    else:
      bot.send_message(message.chat.id, "Я не знаю цю пісню...")

#RUN
bot.polling(none_stop=True)