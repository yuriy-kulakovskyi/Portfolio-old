import telebot
from telebot import types

Token = '1312419327:AAEQICnwEarMIpvCTeIMeHQ--PsRMTF3tzo'

bot = telebot.TeleBot(Token)

@bot.message_handler(commands = ['start'])
def welcome(message):

	#keyboard
	markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
	btn1 = types.KeyboardButton("Star Wars")
	btn2 = types.KeyboardButton("Cyberpunk 2077")
	btn3 = types.KeyboardButton("Marvel")
	markup.add(btn1, btn2, btn3)

	bot.send_message(message.chat.id, "{0.first_name}, Choose  theme:".format(message.from_user,bot.get_me()),
	parse_mode='html', reply_markup=markup)



@bot.message_handler(content_types = ['text'])
def lalala(message):
	if message.chat.type == 'private':
		if message.text == "Star Wars":

			#first inline keyboard
			markup1 = types.InlineKeyboardMarkup(row_width=2)
			item1 = types.InlineKeyboardButton('Light', callback_data='light')
			item2 = types.InlineKeyboardButton('Dark', callback_data='dark')

			markup1.add(item1, item2)

			bot.send_message(message.chat.id, "Light or Dark?", reply_markup=markup1)

		elif message.text == "Cyberpunk 2077":

	 	    #second inline keyboard
	 		markup2 = types.InlineKeyboardMarkup(row_width=2)
	 		btn1 = types.InlineKeyboardButton('Light', callback_data='light1') 
	 		btn2 = types.InlineKeyboardButton('Dark', callback_data='dark1')

	 		markup2.add(btn1, btn2)

	 		bot.send_message(message.chat.id, "Light or Dark?", reply_markup=markup2)

		elif message.text == "Marvel":
			bot.send_message(message.chat.id, "https://wallpaperaccess.com/4k-marvel")
	 		
		else:
			bot.send_message(message.chat.id, "Use Buttons")

#inline keyboard callback
@bot.callback_query_handler(func=lambda call:True)
def callback_inline(call):
	try:
		if call.message:
			if call.data == 'light':
				bot.send_message(call.message.chat.id, 'https://wallpaperaccess.com/star-wars-light')
			elif call.data == 'dark':
				bot.send_message(call.message.chat.id, 'https://wallpaperaccess.com/star-wars-dark')
			elif call.data == 'light1':
				bot.send_message(call.message.chat.id, 'https://unsplash.com/s/photos/cyberpunk')
			elif call.data == 'dark1':
				bot.send_message(call.message.chat.id, 'https://wallpaperaccess.com/dark-cyberpunk')


			#remove inline buttons	
			bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text = "Light or Dark?",
            reply_markup=None)


	except Exception as e:
		print(repr(e))

#RUN
bot.polling(none_stop=True)