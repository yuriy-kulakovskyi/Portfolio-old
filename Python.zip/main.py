#libraries
import pyttsx3

#pyttsx3 settings
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)


engine.say("Enter your name...")
engine.runAndWait()

#programm start
print("Home password game")

#hello function
user = input("Enter your name...""\n")

def Hello():
	string = "Hello " + user
	print(string)
	engine.say(string)
	engine.runAndWait()

#password check function
def password():
	engine.say("Enter password...")
	engine.runAndWait()
	userpass = input("Enter password: ""\n")

	#checking if password is 1989
	if userpass == "1989":
		print("Welcome Home... Sir")
		engine.say("Welcome Home... Sir")
		engine.runAndWait()

	#checking if password is "Friends"
	elif userpass == "Friends":
		print("Hello bro, let's go watch football")
		engine.say("Hello bro, let's go watch football")
		engine.runAndWait()

	#checking if password is some else
	else:
		print("Goodbye!")
		engine.say("Goodbye!")
		engine.runAndWait()

#RUN
Hello()
password()